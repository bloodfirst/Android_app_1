package com.cundong.izhihu.entity;

public abstract class BaseEntity {
	
}