var body = document.body;

set_big_font();

onload = function () {
	body.style.visibility = 'visible';
}


function set_big_font() {
    body.className += 'large ';
    body.style.visibility = 'visible';
    
    return 6;
}
